exports.id = "components_Layout_js-ethereum_web3_js";
exports.ids = ["components_Layout_js-ethereum_web3_js"];
exports.modules = {

/***/ "./components/Header.js":
/*!******************************!*\
  !*** ./components/Header.js ***!
  \******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-react */ "semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../routes */ "./routes.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_3__);

var _jsxFileName = "C:\\Users\\harsh\\Documents\\blockchain\\kickstarter\\components\\Header.js";




const Header = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Menu, {
    style: {
      marginTop: '10px'
    },
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_routes__WEBPACK_IMPORTED_MODULE_3__.Link, {
      route: "/",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
        className: "item",
        children: "CrowdCoin"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Menu.Menu, {
      position: "right",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_routes__WEBPACK_IMPORTED_MODULE_3__.Link, {
        route: "/",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
          className: "item",
          children: "Campaigns"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_routes__WEBPACK_IMPORTED_MODULE_3__.Link, {
        route: "/campaigns/new",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
          className: "item",
          children: "+"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 17,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Header);

/***/ }),

/***/ "./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! semantic-ui-react */ "semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Header */ "./components/Header.js");

var _jsxFileName = "C:\\Users\\harsh\\Documents\\blockchain\\kickstarter\\components\\Layout.js";


 //import 'semantic-ui-css/semantic.min.css'



const Layout = props => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__.Container, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("link", {
        async: true,
        rel: "stylesheet",
        href: "//cdn.jsdelivr.net/npm/semantic-ui@2.0.3/dist/semantic.min.css"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 13
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Header__WEBPACK_IMPORTED_MODULE_4__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 13
    }, undefined), props.children]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Layout);
/* In the next.js documentation, an additional script was also recommended to be added - for jquery
<script
                async
                src="//cdn.jsdelivr.net/npm/semantic-ui@2.0.3/dist/semantic.min.js"
                ></script>
Here 2.0.3 - semantic-ui-react's version number in this app

OR
Instead of using both the above script and link in the head tag, import semantic-ui-css as shown in the comment above
*/

/***/ }),

/***/ "./ethereum/web3.js":
/*!**************************!*\
  !*** ./ethereum/web3.js ***!
  \**************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! web3 */ "web3");
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(web3__WEBPACK_IMPORTED_MODULE_0__);
//Get provider from Metamask

let web3;

if (false) {} else {
  // We are on the server *OR* the user is not running metamask - window is undefined here 
  const provider = new (web3__WEBPACK_IMPORTED_MODULE_0___default().providers.HttpProvider)('https://rinkeby.infura.io/v3/ca8f08b842d14c80bfc995b842790aa7');
  web3 = new (web3__WEBPACK_IMPORTED_MODULE_0___default())(provider);
}

/* harmony default export */ __webpack_exports__["default"] = (web3);

/***/ }),

/***/ "./routes.js":
/*!*******************!*\
  !*** ./routes.js ***!
  \*******************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

//require returns a function, and invoke this automatically upon requiring/importing
const routes = __webpack_require__(/*! next-routes */ "next-routes")(); //dynamic routing
//: denotes wildcard - whatever comes after will be a variable 


routes.add('/campaigns/new', '/campaigns/new').add('/campaigns/:address', '/campaigns/show').add('/campaigns/:address/requests', '/campaigns/requests/index').add('/campaigns/:address/requests/new', '/campaigns/requests/new');
module.exports = routes; //routes object allow to automatically navigate users around the app, and generate linked tags to display inside of React components as well

/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9raWNrc3RhcnRlci8uL2NvbXBvbmVudHMvSGVhZGVyLmpzIiwid2VicGFjazovL2tpY2tzdGFydGVyLy4vY29tcG9uZW50cy9MYXlvdXQuanMiLCJ3ZWJwYWNrOi8va2lja3N0YXJ0ZXIvLi9ldGhlcmV1bS93ZWIzLmpzIiwid2VicGFjazovL2tpY2tzdGFydGVyLy4vcm91dGVzLmpzIl0sIm5hbWVzIjpbIkhlYWRlciIsIm1hcmdpblRvcCIsIkxheW91dCIsInByb3BzIiwiY2hpbGRyZW4iLCJ3ZWIzIiwicHJvdmlkZXIiLCJXZWIzIiwicm91dGVzIiwicmVxdWlyZSIsImFkZCIsIm1vZHVsZSIsImV4cG9ydHMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBRUE7O0FBRUEsTUFBTUEsTUFBTSxHQUFHLE1BQU07QUFDakIsc0JBQ0ksOERBQUMsbURBQUQ7QUFBTSxTQUFLLEVBQUk7QUFBRUMsZUFBUyxFQUFFO0FBQWIsS0FBZjtBQUFBLDRCQUNJLDhEQUFDLHlDQUFEO0FBQU0sV0FBSyxFQUFHLEdBQWQ7QUFBQSw2QkFDSTtBQUFHLGlCQUFTLEVBQUcsTUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFJSSw4REFBQyx3REFBRDtBQUFXLGNBQVEsRUFBRyxPQUF0QjtBQUFBLDhCQUNJLDhEQUFDLHlDQUFEO0FBQU0sYUFBSyxFQUFHLEdBQWQ7QUFBQSwrQkFDSTtBQUFHLG1CQUFTLEVBQUcsTUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFJSSw4REFBQyx5Q0FBRDtBQUFNLGFBQUssRUFBRyxnQkFBZDtBQUFBLCtCQUNJO0FBQUcsbUJBQVMsRUFBRyxNQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFlSCxDQWhCRDs7QUFrQkEsK0RBQWVELE1BQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2QkE7QUFDQTtDQUVBOztBQUVBOztBQUVBLE1BQU1FLE1BQU0sR0FBSUMsS0FBRCxJQUFXO0FBQ3RCLHNCQUNJLDhEQUFDLHdEQUFEO0FBQUEsNEJBQ0ksOERBQUMsa0RBQUQ7QUFBQSw2QkFDQTtBQUNJLGFBQUssTUFEVDtBQUVJLFdBQUcsRUFBQyxZQUZSO0FBR0ksWUFBSSxFQUFDO0FBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFRSSw4REFBQyw0Q0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVJKLEVBU0tBLEtBQUssQ0FBQ0MsUUFUWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQWFILENBZEQ7O0FBZ0JBLCtEQUFlRixNQUFmO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsRTs7Ozs7Ozs7Ozs7Ozs7QUNsQ0E7QUFFQTtBQUVBLElBQUlHLElBQUo7O0FBRUEsSUFBSSxLQUFKLEVBQTZFLEVBQTdFLE1BSU87QUFDTDtBQUNBLFFBQU1DLFFBQVEsR0FBRyxJQUFJQyxvRUFBSixDQUNmLCtEQURlLENBQWpCO0FBR0FGLE1BQUksR0FBRyxJQUFJRSw2Q0FBSixDQUFTRCxRQUFULENBQVA7QUFDRDs7QUFFRCwrREFBZUQsSUFBZixFOzs7Ozs7Ozs7O0FDbEJBO0FBQ0EsTUFBTUcsTUFBTSxHQUFHQyxtQkFBTyxDQUFDLGdDQUFELENBQVAsRUFBZixDLENBRUE7QUFDQTs7O0FBQ0FELE1BQU0sQ0FDREUsR0FETCxDQUNTLGdCQURULEVBQzJCLGdCQUQzQixFQUVLQSxHQUZMLENBRVMscUJBRlQsRUFFZ0MsaUJBRmhDLEVBR0tBLEdBSEwsQ0FHUyw4QkFIVCxFQUd5QywyQkFIekMsRUFJS0EsR0FKTCxDQUlTLGtDQUpULEVBSTZDLHlCQUo3QztBQU1BQyxNQUFNLENBQUNDLE9BQVAsR0FBaUJKLE1BQWpCLEMsQ0FDQSw0SSIsImZpbGUiOiJjb21wb25lbnRzX0xheW91dF9qcy1ldGhlcmV1bV93ZWIzX2pzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTWVudSB9IGZyb20gJ3NlbWFudGljLXVpLXJlYWN0JztcclxuXHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICcuLi9yb3V0ZXMnO1xyXG5cclxuY29uc3QgSGVhZGVyID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuKFxyXG4gICAgICAgIDxNZW51IHN0eWxlID0ge3sgbWFyZ2luVG9wOiAnMTBweCd9fT5cclxuICAgICAgICAgICAgPExpbmsgcm91dGUgPSBcIi9cIj5cclxuICAgICAgICAgICAgICAgIDxhIGNsYXNzTmFtZSA9IFwiaXRlbVwiPkNyb3dkQ29pbjwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8TWVudS5NZW51IHBvc2l0aW9uID0gXCJyaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgPExpbmsgcm91dGUgPSBcIi9cIj5cclxuICAgICAgICAgICAgICAgICAgICA8YSBjbGFzc05hbWUgPSBcIml0ZW1cIj5DYW1wYWlnbnM8L2E+XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8TGluayByb3V0ZSA9IFwiL2NhbXBhaWducy9uZXdcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YSBjbGFzc05hbWUgPSBcIml0ZW1cIj4rPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L01lbnUuTWVudT5cclxuICAgICAgICA8L01lbnU+XHJcbiAgICApO1xyXG59O1xyXG4gIFxyXG5leHBvcnQgZGVmYXVsdCBIZWFkZXI7IiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJztcclxuaW1wb3J0IHsgQ29udGFpbmVyIH0gZnJvbSAnc2VtYW50aWMtdWktcmVhY3QnXHJcbi8vaW1wb3J0ICdzZW1hbnRpYy11aS1jc3Mvc2VtYW50aWMubWluLmNzcydcclxuXHJcbmltcG9ydCBIZWFkZXIgZnJvbSAnLi9IZWFkZXInO1xyXG5cclxuY29uc3QgTGF5b3V0ID0gKHByb3BzKSA9PiB7XHJcbiAgICByZXR1cm4oXHJcbiAgICAgICAgPENvbnRhaW5lcj5cclxuICAgICAgICAgICAgPEhlYWQ+XHJcbiAgICAgICAgICAgIDxsaW5rXHJcbiAgICAgICAgICAgICAgICBhc3luY1xyXG4gICAgICAgICAgICAgICAgcmVsPVwic3R5bGVzaGVldFwiXHJcbiAgICAgICAgICAgICAgICBocmVmPVwiLy9jZG4uanNkZWxpdnIubmV0L25wbS9zZW1hbnRpYy11aUAyLjAuMy9kaXN0L3NlbWFudGljLm1pbi5jc3NcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9IZWFkPlxyXG4gICAgICAgICAgICA8SGVhZGVyIC8+XHJcbiAgICAgICAgICAgIHtwcm9wcy5jaGlsZHJlbn1cclxuICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICk7XHJcbn07XHJcbiAgXHJcbmV4cG9ydCBkZWZhdWx0IExheW91dDtcclxuXHJcbi8qIEluIHRoZSBuZXh0LmpzIGRvY3VtZW50YXRpb24sIGFuIGFkZGl0aW9uYWwgc2NyaXB0IHdhcyBhbHNvIHJlY29tbWVuZGVkIHRvIGJlIGFkZGVkIC0gZm9yIGpxdWVyeVxyXG48c2NyaXB0XHJcbiAgICAgICAgICAgICAgICBhc3luY1xyXG4gICAgICAgICAgICAgICAgc3JjPVwiLy9jZG4uanNkZWxpdnIubmV0L25wbS9zZW1hbnRpYy11aUAyLjAuMy9kaXN0L3NlbWFudGljLm1pbi5qc1wiXHJcbiAgICAgICAgICAgICAgICA+PC9zY3JpcHQ+XHJcbkhlcmUgMi4wLjMgLSBzZW1hbnRpYy11aS1yZWFjdCdzIHZlcnNpb24gbnVtYmVyIGluIHRoaXMgYXBwXHJcblxyXG5PUlxyXG5JbnN0ZWFkIG9mIHVzaW5nIGJvdGggdGhlIGFib3ZlIHNjcmlwdCBhbmQgbGluayBpbiB0aGUgaGVhZCB0YWcsIGltcG9ydCBzZW1hbnRpYy11aS1jc3MgYXMgc2hvd24gaW4gdGhlIGNvbW1lbnQgYWJvdmVcclxuKi8iLCIvL0dldCBwcm92aWRlciBmcm9tIE1ldGFtYXNrXHJcblxyXG5pbXBvcnQgV2ViMyBmcm9tIFwid2ViM1wiO1xyXG4gXHJcbmxldCB3ZWIzO1xyXG4gXHJcbmlmICh0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHR5cGVvZiB3aW5kb3cuZXRoZXJldW0gIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAvLyBXZSBhcmUgaW4gdGhlIGJyb3dzZXIgYW5kIG1ldGFtYXNrIGlzIHJ1bm5pbmcuXHJcbiAgd2luZG93LmV0aGVyZXVtLnJlcXVlc3QoeyBtZXRob2Q6IFwiZXRoX3JlcXVlc3RBY2NvdW50c1wiIH0pO1xyXG4gIHdlYjMgPSBuZXcgV2ViMyh3aW5kb3cuZXRoZXJldW0pO1xyXG59IGVsc2Uge1xyXG4gIC8vIFdlIGFyZSBvbiB0aGUgc2VydmVyICpPUiogdGhlIHVzZXIgaXMgbm90IHJ1bm5pbmcgbWV0YW1hc2sgLSB3aW5kb3cgaXMgdW5kZWZpbmVkIGhlcmUgXHJcbiAgY29uc3QgcHJvdmlkZXIgPSBuZXcgV2ViMy5wcm92aWRlcnMuSHR0cFByb3ZpZGVyKFxyXG4gICAgJ2h0dHBzOi8vcmlua2VieS5pbmZ1cmEuaW8vdjMvY2E4ZjA4Yjg0MmQxNGM4MGJmYzk5NWI4NDI3OTBhYTcnXHJcbiAgKTtcclxuICB3ZWIzID0gbmV3IFdlYjMocHJvdmlkZXIpO1xyXG59XHJcbiBcclxuZXhwb3J0IGRlZmF1bHQgd2ViMzsiLCIvL3JlcXVpcmUgcmV0dXJucyBhIGZ1bmN0aW9uLCBhbmQgaW52b2tlIHRoaXMgYXV0b21hdGljYWxseSB1cG9uIHJlcXVpcmluZy9pbXBvcnRpbmdcclxuY29uc3Qgcm91dGVzID0gcmVxdWlyZSgnbmV4dC1yb3V0ZXMnKSgpO1xyXG5cclxuLy9keW5hbWljIHJvdXRpbmdcclxuLy86IGRlbm90ZXMgd2lsZGNhcmQgLSB3aGF0ZXZlciBjb21lcyBhZnRlciB3aWxsIGJlIGEgdmFyaWFibGUgXHJcbnJvdXRlc1xyXG4gICAgLmFkZCgnL2NhbXBhaWducy9uZXcnLCAnL2NhbXBhaWducy9uZXcnKVxyXG4gICAgLmFkZCgnL2NhbXBhaWducy86YWRkcmVzcycsICcvY2FtcGFpZ25zL3Nob3cnKVxyXG4gICAgLmFkZCgnL2NhbXBhaWducy86YWRkcmVzcy9yZXF1ZXN0cycsICcvY2FtcGFpZ25zL3JlcXVlc3RzL2luZGV4JylcclxuICAgIC5hZGQoJy9jYW1wYWlnbnMvOmFkZHJlc3MvcmVxdWVzdHMvbmV3JywgJy9jYW1wYWlnbnMvcmVxdWVzdHMvbmV3Jyk7XHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IHJvdXRlcztcclxuLy9yb3V0ZXMgb2JqZWN0IGFsbG93IHRvIGF1dG9tYXRpY2FsbHkgbmF2aWdhdGUgdXNlcnMgYXJvdW5kIHRoZSBhcHAsIGFuZCBnZW5lcmF0ZSBsaW5rZWQgdGFncyB0byBkaXNwbGF5IGluc2lkZSBvZiBSZWFjdCBjb21wb25lbnRzIGFzIHdlbGwiXSwic291cmNlUm9vdCI6IiJ9