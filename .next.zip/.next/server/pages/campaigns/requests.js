(function() {
var exports = {};
exports.id = "pages/campaigns/requests";
exports.ids = ["pages/campaigns/requests"];
exports.modules = {

/***/ "./components/RequestRow.js":
/*!**********************************!*\
  !*** ./components/RequestRow.js ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-react */ "semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ethereum_campaign__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../ethereum/campaign */ "./ethereum/campaign.js");
/* harmony import */ var _ethereum_web3__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../ethereum/web3 */ "./ethereum/web3.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../routes */ "./routes.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_5__);

var _jsxFileName = "C:\\Users\\harsh\\Documents\\blockchain\\kickstarter\\components\\RequestRow.js";

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







class RequestRow extends react__WEBPACK_IMPORTED_MODULE_1__.Component {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "state", {
      loadingA: false,
      loadingF: false,
      errorMessage: ''
    });

    _defineProperty(this, "onApprove", async () => {
      this.setState({
        loadingA: true,
        errorMessage: ''
      });

      try {
        const campaign = (0,_ethereum_campaign__WEBPACK_IMPORTED_MODULE_3__.default)(this.props.address);
        const accounts = await _ethereum_web3__WEBPACK_IMPORTED_MODULE_4__.default.eth.getAccounts();
        await campaign.methods.approveRequest(this.props.id).send({
          from: accounts[0]
        });
        _routes__WEBPACK_IMPORTED_MODULE_5__.Router.replaceRoute(`/campaigns/${this.props.address}/requests`);
      } catch (err) {
        this.setState({
          errorMessage: err.message
        });
      }

      this.setState({
        loadingA: false
      });
    });

    _defineProperty(this, "onFinalize", async () => {
      this.setState({
        loadingF: true,
        errorMessage: ''
      });

      try {
        const campaign = (0,_ethereum_campaign__WEBPACK_IMPORTED_MODULE_3__.default)(this.props.address);
        const accounts = await _ethereum_web3__WEBPACK_IMPORTED_MODULE_4__.default.eth.getAccounts();
        await campaign.methods.finalizeRequest(this.props.id).send({
          from: accounts[0]
        });
        _routes__WEBPACK_IMPORTED_MODULE_5__.Router.replaceRoute(`/campaigns/${this.props.address}/requests`);
      } catch (err) {
        this.setState({
          errorMessage: err.message
        });
      }

      this.setState({
        loadingF: false
      });
    });
  }

  render() {
    const {
      Row,
      Cell
    } = semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Table;
    const {
      id,
      request,
      approversCount
    } = this.props;
    const readyToFinalize = request.approvalCount >= approversCount / 2;
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Row, {
      disabled: request.complete,
      positive: readyToFinalize && !request.complete,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Cell, {
        children: id
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Cell, {
        children: request.description
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Cell, {
        children: _ethereum_web3__WEBPACK_IMPORTED_MODULE_4__.default.utils.fromWei(request.value, 'ether')
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Cell, {
        children: request.recipient
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Cell, {
        children: [request.approvalCount, "/", approversCount]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Cell, {
        children: request.complete ? null : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
          basic: true,
          color: "green",
          onClick: this.onApprove,
          loading: this.state.loadingA,
          disabled: this.state.loadingA,
          children: "Approve"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 62,
          columnNumber: 26
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Cell, {
        children: request.complete ? null : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
          basic: true,
          color: "teal",
          onClick: this.onFinalize,
          loading: this.state.loadingF,
          disabled: this.state.loadingF,
          children: "Finalize"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 26
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Cell, {
        error: !!this.state.errorMessage,
        children: !!this.state.errorMessage ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Message, {
          error: true,
          header: "Oops!",
          content: this.state.errorMessage
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 44
        }, this) : null
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 13
    }, this);
  }

}

/* harmony default export */ __webpack_exports__["default"] = (RequestRow);

/***/ }),

/***/ "./pages/campaigns/requests/index.js":
/*!*******************************************!*\
  !*** ./pages/campaigns/requests/index.js ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-react */ "semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../components/Layout */ "./components/Layout.js");
/* harmony import */ var _components_RequestRow__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../components/RequestRow */ "./components/RequestRow.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../routes */ "./routes.js");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_routes__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ethereum_campaign__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../ethereum/campaign */ "./ethereum/campaign.js");

var _jsxFileName = "C:\\Users\\harsh\\Documents\\blockchain\\kickstarter\\pages\\campaigns\\requests\\index.js";







class RequestIndex extends react__WEBPACK_IMPORTED_MODULE_1__.Component {
  static async getInitialProps(props) {
    const {
      address
    } = props.query; //Solidity does not support returning an array of user defined types like structs -
    //To get a list of all requests, we need to call separately for each request
    //Use the requests count and call each one

    const campaign = (0,_ethereum_campaign__WEBPACK_IMPORTED_MODULE_6__.default)(address);
    const requestCount = await campaign.methods.getRequestsCount().call();
    const approversCount = await campaign.methods.approversCount().call(); //Instead of creating a loop and fetching requests one by one, send them all together 
    //Array.fill(num).map(...) - gives all the indices from 0 to num

    const requests = await Promise.all(Array(parseInt(requestCount)).fill().map((element, index) => {
      return campaign.methods.requests(index).call();
    }));
    console.log(requests);
    return {
      address,
      requests,
      requestCount,
      approversCount
    };
  }

  renderRows() {
    return this.props.requests.map((request, index) => {
      return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_RequestRow__WEBPACK_IMPORTED_MODULE_4__.default, {
        id: index,
        request: request,
        address: this.props.address,
        approversCount: this.props.approversCount
      }, index, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 20
      }, this);
    });
  }

  render() {
    const {
      Header,
      Row,
      HeaderCell,
      Body
    } = semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Table;
    return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_3__.default, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_routes__WEBPACK_IMPORTED_MODULE_5__.Link, {
        route: `/campaigns/${this.props.address}`,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
          children: "Back"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
        children: "Requests"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_routes__WEBPACK_IMPORTED_MODULE_5__.Link, {
        route: `/campaigns/${this.props.address}/requests/new`,
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
            primary: true,
            floated: "right",
            style: {
              marginBottom: 10
            },
            children: "Add Request"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Table, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Header, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Row, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HeaderCell, {
              children: "ID"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 63,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HeaderCell, {
              children: "Description"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 64,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HeaderCell, {
              children: "Amount"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 65,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HeaderCell, {
              children: "Recipient"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 66,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HeaderCell, {
              children: "Approval Count"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 67,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HeaderCell, {
              children: "Approve"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 68,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HeaderCell, {
              children: "Finalize"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 69,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(HeaderCell, {
              children: "Notes"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 70,
              columnNumber: 29
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 62,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Body, {
          children: this.renderRows()
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 73,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        children: ["Found ", this.props.requestCount, " requests."]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 13
    }, this);
  }

}

/* harmony default export */ __webpack_exports__["default"] = (RequestIndex);

/***/ }),

/***/ "next-routes":
/*!******************************!*\
  !*** external "next-routes" ***!
  \******************************/
/***/ (function(module) {

"use strict";
module.exports = require("next-routes");;

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-dev-runtime");;

/***/ }),

/***/ "semantic-ui-react":
/*!************************************!*\
  !*** external "semantic-ui-react" ***!
  \************************************/
/***/ (function(module) {

"use strict";
module.exports = require("semantic-ui-react");;

/***/ }),

/***/ "web3":
/*!***********************!*\
  !*** external "web3" ***!
  \***********************/
/***/ (function(module) {

"use strict";
module.exports = require("web3");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, ["components_Layout_js-ethereum_web3_js","ethereum_campaign_js"], function() { return __webpack_exec__("./pages/campaigns/requests/index.js"); });
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9raWNrc3RhcnRlci8uL2NvbXBvbmVudHMvUmVxdWVzdFJvdy5qcyIsIndlYnBhY2s6Ly9raWNrc3RhcnRlci8uL3BhZ2VzL2NhbXBhaWducy9yZXF1ZXN0cy9pbmRleC5qcyIsIndlYnBhY2s6Ly9raWNrc3RhcnRlci9leHRlcm5hbCBcIm5leHQtcm91dGVzXCIiLCJ3ZWJwYWNrOi8va2lja3N0YXJ0ZXIvZXh0ZXJuYWwgXCJuZXh0L2hlYWRcIiIsIndlYnBhY2s6Ly9raWNrc3RhcnRlci9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8va2lja3N0YXJ0ZXIvZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIiIsIndlYnBhY2s6Ly9raWNrc3RhcnRlci9leHRlcm5hbCBcInNlbWFudGljLXVpLXJlYWN0XCIiLCJ3ZWJwYWNrOi8va2lja3N0YXJ0ZXIvZXh0ZXJuYWwgXCJ3ZWIzXCIiXSwibmFtZXMiOlsiUmVxdWVzdFJvdyIsIkNvbXBvbmVudCIsImxvYWRpbmdBIiwibG9hZGluZ0YiLCJlcnJvck1lc3NhZ2UiLCJzZXRTdGF0ZSIsImNhbXBhaWduIiwiQ2FtcGFpZ24iLCJwcm9wcyIsImFkZHJlc3MiLCJhY2NvdW50cyIsIndlYjMiLCJtZXRob2RzIiwiYXBwcm92ZVJlcXVlc3QiLCJpZCIsInNlbmQiLCJmcm9tIiwiUm91dGVyIiwiZXJyIiwibWVzc2FnZSIsImZpbmFsaXplUmVxdWVzdCIsInJlbmRlciIsIlJvdyIsIkNlbGwiLCJUYWJsZSIsInJlcXVlc3QiLCJhcHByb3ZlcnNDb3VudCIsInJlYWR5VG9GaW5hbGl6ZSIsImFwcHJvdmFsQ291bnQiLCJjb21wbGV0ZSIsImRlc2NyaXB0aW9uIiwidmFsdWUiLCJyZWNpcGllbnQiLCJvbkFwcHJvdmUiLCJzdGF0ZSIsIm9uRmluYWxpemUiLCJSZXF1ZXN0SW5kZXgiLCJnZXRJbml0aWFsUHJvcHMiLCJxdWVyeSIsInJlcXVlc3RDb3VudCIsImdldFJlcXVlc3RzQ291bnQiLCJjYWxsIiwicmVxdWVzdHMiLCJQcm9taXNlIiwiYWxsIiwiQXJyYXkiLCJwYXJzZUludCIsImZpbGwiLCJtYXAiLCJlbGVtZW50IiwiaW5kZXgiLCJjb25zb2xlIiwibG9nIiwicmVuZGVyUm93cyIsIkhlYWRlciIsIkhlYWRlckNlbGwiLCJCb2R5IiwibWFyZ2luQm90dG9tIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFFQTtBQUNBO0FBRUE7O0FBRUEsTUFBTUEsVUFBTixTQUF5QkMsNENBQXpCLENBQW1DO0FBQUE7QUFBQTs7QUFBQSxtQ0FDdkI7QUFDSkMsY0FBUSxFQUFFLEtBRE47QUFFSkMsY0FBUSxFQUFFLEtBRk47QUFHSkMsa0JBQVksRUFBRTtBQUhWLEtBRHVCOztBQUFBLHVDQU9uQixZQUFZO0FBQ3BCLFdBQUtDLFFBQUwsQ0FBYztBQUFFSCxnQkFBUSxFQUFFLElBQVo7QUFBa0JFLG9CQUFZLEVBQUU7QUFBaEMsT0FBZDs7QUFDQSxVQUFJO0FBQ0EsY0FBTUUsUUFBUSxHQUFHQywyREFBUSxDQUFDLEtBQUtDLEtBQUwsQ0FBV0MsT0FBWixDQUF6QjtBQUNBLGNBQU1DLFFBQVEsR0FBRyxNQUFNQyxtRUFBQSxFQUF2QjtBQUNBLGNBQU1MLFFBQVEsQ0FBQ00sT0FBVCxDQUFpQkMsY0FBakIsQ0FBZ0MsS0FBS0wsS0FBTCxDQUFXTSxFQUEzQyxFQUNEQyxJQURDLENBQ0k7QUFBRUMsY0FBSSxFQUFFTixRQUFRLENBQUMsQ0FBRDtBQUFoQixTQURKLENBQU47QUFFQU8sZ0VBQUEsQ0FBcUIsY0FBYSxLQUFLVCxLQUFMLENBQVdDLE9BQVEsV0FBckQ7QUFDSCxPQU5ELENBTUUsT0FBT1MsR0FBUCxFQUFZO0FBQ1YsYUFBS2IsUUFBTCxDQUFjO0FBQUVELHNCQUFZLEVBQUVjLEdBQUcsQ0FBQ0M7QUFBcEIsU0FBZDtBQUNIOztBQUVELFdBQUtkLFFBQUwsQ0FBYztBQUFFSCxnQkFBUSxFQUFFO0FBQVosT0FBZDtBQUVILEtBckI4Qjs7QUFBQSx3Q0F1QmxCLFlBQVk7QUFDckIsV0FBS0csUUFBTCxDQUFjO0FBQUVGLGdCQUFRLEVBQUUsSUFBWjtBQUFrQkMsb0JBQVksRUFBRTtBQUFoQyxPQUFkOztBQUNBLFVBQUk7QUFDQSxjQUFNRSxRQUFRLEdBQUdDLDJEQUFRLENBQUMsS0FBS0MsS0FBTCxDQUFXQyxPQUFaLENBQXpCO0FBQ0EsY0FBTUMsUUFBUSxHQUFHLE1BQU1DLG1FQUFBLEVBQXZCO0FBQ0EsY0FBTUwsUUFBUSxDQUFDTSxPQUFULENBQWlCUSxlQUFqQixDQUFpQyxLQUFLWixLQUFMLENBQVdNLEVBQTVDLEVBQ0RDLElBREMsQ0FDSTtBQUFFQyxjQUFJLEVBQUVOLFFBQVEsQ0FBQyxDQUFEO0FBQWhCLFNBREosQ0FBTjtBQUVBTyxnRUFBQSxDQUFxQixjQUFhLEtBQUtULEtBQUwsQ0FBV0MsT0FBUSxXQUFyRDtBQUNILE9BTkQsQ0FNRSxPQUFPUyxHQUFQLEVBQVk7QUFDVixhQUFLYixRQUFMLENBQWM7QUFBRUQsc0JBQVksRUFBRWMsR0FBRyxDQUFDQztBQUFwQixTQUFkO0FBQ0g7O0FBRUQsV0FBS2QsUUFBTCxDQUFjO0FBQUVGLGdCQUFRLEVBQUU7QUFBWixPQUFkO0FBRUgsS0FyQzhCO0FBQUE7O0FBdUMvQmtCLFFBQU0sR0FBRztBQUNMLFVBQU07QUFBRUMsU0FBRjtBQUFPQztBQUFQLFFBQWdCQyxvREFBdEI7QUFDQSxVQUFNO0FBQUVWLFFBQUY7QUFBTVcsYUFBTjtBQUFlQztBQUFmLFFBQWtDLEtBQUtsQixLQUE3QztBQUNBLFVBQU1tQixlQUFlLEdBQUdGLE9BQU8sQ0FBQ0csYUFBUixJQUF5QkYsY0FBYyxHQUFHLENBQWxFO0FBRUEsd0JBQ0ksOERBQUMsR0FBRDtBQUFLLGNBQVEsRUFBSUQsT0FBTyxDQUFDSSxRQUF6QjtBQUFtQyxjQUFRLEVBQUlGLGVBQWUsSUFBSSxDQUFDRixPQUFPLENBQUNJLFFBQTNFO0FBQUEsOEJBQ0ksOERBQUMsSUFBRDtBQUFBLGtCQUFPZjtBQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FESixlQUVJLDhEQUFDLElBQUQ7QUFBQSxrQkFBT1csT0FBTyxDQUFDSztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGSixlQUdJLDhEQUFDLElBQUQ7QUFBQSxrQkFBT25CLGlFQUFBLENBQW9CYyxPQUFPLENBQUNNLEtBQTVCLEVBQW1DLE9BQW5DO0FBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhKLGVBSUksOERBQUMsSUFBRDtBQUFBLGtCQUFPTixPQUFPLENBQUNPO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUpKLGVBS0ksOERBQUMsSUFBRDtBQUFBLG1CQUFPUCxPQUFPLENBQUNHLGFBQWYsT0FBK0JGLGNBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUxKLGVBTUksOERBQUMsSUFBRDtBQUFBLGtCQUNNRCxPQUFPLENBQUNJLFFBQVIsR0FBbUIsSUFBbkIsZ0JBQ0csOERBQUMscURBQUQ7QUFBUSxlQUFLLE1BQWI7QUFBYyxlQUFLLEVBQUMsT0FBcEI7QUFBNEIsaUJBQU8sRUFBRSxLQUFLSSxTQUExQztBQUFxRCxpQkFBTyxFQUFJLEtBQUtDLEtBQUwsQ0FBV2hDLFFBQTNFO0FBQXFGLGtCQUFRLEVBQUksS0FBS2dDLEtBQUwsQ0FBV2hDLFFBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU5KLGVBVUksOERBQUMsSUFBRDtBQUFBLGtCQUNNdUIsT0FBTyxDQUFDSSxRQUFSLEdBQW1CLElBQW5CLGdCQUNHLDhEQUFDLHFEQUFEO0FBQVEsZUFBSyxNQUFiO0FBQWMsZUFBSyxFQUFDLE1BQXBCO0FBQTJCLGlCQUFPLEVBQUUsS0FBS00sVUFBekM7QUFBcUQsaUJBQU8sRUFBSSxLQUFLRCxLQUFMLENBQVcvQixRQUEzRTtBQUFxRixrQkFBUSxFQUFJLEtBQUsrQixLQUFMLENBQVcvQixRQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZUO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FWSixlQWNJLDhEQUFDLElBQUQ7QUFBTSxhQUFLLEVBQUksQ0FBQyxDQUFDLEtBQUsrQixLQUFMLENBQVc5QixZQUE1QjtBQUFBLGtCQUNDLENBQUMsQ0FBQyxLQUFLOEIsS0FBTCxDQUFXOUIsWUFBYixnQkFBMEIsOERBQUMsc0RBQUQ7QUFBUyxlQUFLLE1BQWQ7QUFBZSxnQkFBTSxFQUFHLE9BQXhCO0FBQWdDLGlCQUFPLEVBQUksS0FBSzhCLEtBQUwsQ0FBVzlCO0FBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBQTFCLEdBQWdHO0FBRGpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFESjtBQW9CSDs7QUFoRThCOztBQW1FbkMsK0RBQWVKLFVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNFQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBRUE7O0FBRUEsTUFBTW9DLFlBQU4sU0FBMkJuQyw0Q0FBM0IsQ0FBcUM7QUFDakMsZUFBYW9DLGVBQWIsQ0FBNkI3QixLQUE3QixFQUFvQztBQUNoQyxVQUFNO0FBQUVDO0FBQUYsUUFBY0QsS0FBSyxDQUFDOEIsS0FBMUIsQ0FEZ0MsQ0FFaEM7QUFDQTtBQUNBOztBQUNBLFVBQU1oQyxRQUFRLEdBQUdDLDJEQUFRLENBQUNFLE9BQUQsQ0FBekI7QUFDQSxVQUFNOEIsWUFBWSxHQUFHLE1BQU1qQyxRQUFRLENBQUNNLE9BQVQsQ0FBaUI0QixnQkFBakIsR0FBb0NDLElBQXBDLEVBQTNCO0FBQ0EsVUFBTWYsY0FBYyxHQUFHLE1BQU1wQixRQUFRLENBQUNNLE9BQVQsQ0FBaUJjLGNBQWpCLEdBQWtDZSxJQUFsQyxFQUE3QixDQVBnQyxDQVNoQztBQUNBOztBQUNBLFVBQU1DLFFBQVEsR0FBRyxNQUFNQyxPQUFPLENBQUNDLEdBQVIsQ0FDbkJDLEtBQUssQ0FBQ0MsUUFBUSxDQUFDUCxZQUFELENBQVQsQ0FBTCxDQUE4QlEsSUFBOUIsR0FBcUNDLEdBQXJDLENBQXlDLENBQUVDLE9BQUYsRUFBV0MsS0FBWCxLQUFxQjtBQUMxRCxhQUFPNUMsUUFBUSxDQUFDTSxPQUFULENBQWlCOEIsUUFBakIsQ0FBMEJRLEtBQTFCLEVBQWlDVCxJQUFqQyxFQUFQO0FBQ0gsS0FGRCxDQURtQixDQUF2QjtBQU1BVSxXQUFPLENBQUNDLEdBQVIsQ0FBWVYsUUFBWjtBQUVBLFdBQU87QUFBRWpDLGFBQUY7QUFBV2lDLGNBQVg7QUFBcUJILGtCQUFyQjtBQUFtQ2I7QUFBbkMsS0FBUDtBQUNIOztBQUVEMkIsWUFBVSxHQUFHO0FBQ1QsV0FBTyxLQUFLN0MsS0FBTCxDQUFXa0MsUUFBWCxDQUFvQk0sR0FBcEIsQ0FBd0IsQ0FBQ3ZCLE9BQUQsRUFBVXlCLEtBQVYsS0FBb0I7QUFDL0MsMEJBQU8sOERBQUMsMkRBQUQ7QUFFSCxVQUFFLEVBQUlBLEtBRkg7QUFHSCxlQUFPLEVBQUl6QixPQUhSO0FBSUgsZUFBTyxFQUFJLEtBQUtqQixLQUFMLENBQVdDLE9BSm5CO0FBS0gsc0JBQWMsRUFBSSxLQUFLRCxLQUFMLENBQVdrQjtBQUwxQixTQUNJd0IsS0FESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQVA7QUFPSCxLQVJNLENBQVA7QUFTSDs7QUFFRDdCLFFBQU0sR0FBRTtBQUNKLFVBQU07QUFBRWlDLFlBQUY7QUFBVWhDLFNBQVY7QUFBZWlDLGdCQUFmO0FBQTJCQztBQUEzQixRQUFvQ2hDLG9EQUExQztBQUVBLHdCQUNJLDhEQUFDLHVEQUFEO0FBQUEsOEJBQ0ksOERBQUMseUNBQUQ7QUFBTSxhQUFLLEVBQUssY0FBYSxLQUFLaEIsS0FBTCxDQUFXQyxPQUFRLEVBQWhEO0FBQUEsK0JBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREosZUFJSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUpKLGVBS0ksOERBQUMseUNBQUQ7QUFBTSxhQUFLLEVBQUcsY0FBYSxLQUFLRCxLQUFMLENBQVdDLE9BQVEsZUFBOUM7QUFBQSwrQkFDSTtBQUFBLGlDQUNJLDhEQUFDLHFEQUFEO0FBQVEsbUJBQU8sTUFBZjtBQUFnQixtQkFBTyxFQUFHLE9BQTFCO0FBQWtDLGlCQUFLLEVBQUk7QUFBRWdELDBCQUFZLEVBQUU7QUFBaEIsYUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUxKLGVBVUksOERBQUMsb0RBQUQ7QUFBQSxnQ0FDSSw4REFBQyxNQUFEO0FBQUEsaUNBQ0ksOERBQUMsR0FBRDtBQUFBLG9DQUNJLDhEQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREosZUFFSSw4REFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUZKLGVBR0ksOERBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFISixlQUlJLDhEQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSkosZUFLSSw4REFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUxKLGVBTUksOERBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFOSixlQU9JLDhEQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUEosZUFRSSw4REFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREosZUFhSSw4REFBQyxJQUFEO0FBQUEsb0JBQ0ssS0FBS0osVUFBTDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVkosZUEyQkk7QUFBQSw2QkFBWSxLQUFLN0MsS0FBTCxDQUFXK0IsWUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKO0FBK0JIOztBQXJFZ0M7O0FBd0VyQywrREFBZUgsWUFBZixFOzs7Ozs7Ozs7OztBQ2xGQSx5Qzs7Ozs7Ozs7Ozs7QUNBQSx1Qzs7Ozs7Ozs7Ozs7QUNBQSxtQzs7Ozs7Ozs7Ozs7QUNBQSxtRDs7Ozs7Ozs7Ozs7QUNBQSwrQzs7Ozs7Ozs7Ozs7QUNBQSxrQyIsImZpbGUiOiJwYWdlcy9jYW1wYWlnbnMvcmVxdWVzdHMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBCdXR0b24sIE1lc3NhZ2UsIFRhYmxlIH0gZnJvbSAnc2VtYW50aWMtdWktcmVhY3QnO1xyXG5cclxuaW1wb3J0IENhbXBhaWduIGZyb20gJy4uL2V0aGVyZXVtL2NhbXBhaWduJztcclxuaW1wb3J0IHdlYjMgZnJvbSAnLi4vZXRoZXJldW0vd2ViMyc7XHJcblxyXG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICcuLi9yb3V0ZXMnO1xyXG5cclxuY2xhc3MgUmVxdWVzdFJvdyBleHRlbmRzIENvbXBvbmVudCB7XHJcbiAgICBzdGF0ZSA9IHtcclxuICAgICAgICBsb2FkaW5nQTogZmFsc2UsXHJcbiAgICAgICAgbG9hZGluZ0Y6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yTWVzc2FnZTogJydcclxuICAgIH07XHJcblxyXG4gICAgb25BcHByb3ZlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyBsb2FkaW5nQTogdHJ1ZSwgZXJyb3JNZXNzYWdlOiAnJ30pO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGNhbXBhaWduID0gQ2FtcGFpZ24odGhpcy5wcm9wcy5hZGRyZXNzKTtcclxuICAgICAgICAgICAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCB3ZWIzLmV0aC5nZXRBY2NvdW50cygpO1xyXG4gICAgICAgICAgICBhd2FpdCBjYW1wYWlnbi5tZXRob2RzLmFwcHJvdmVSZXF1ZXN0KHRoaXMucHJvcHMuaWQpXHJcbiAgICAgICAgICAgICAgICAuc2VuZCh7IGZyb206IGFjY291bnRzWzBdIH0pO1xyXG4gICAgICAgICAgICBSb3V0ZXIucmVwbGFjZVJvdXRlKGAvY2FtcGFpZ25zLyR7dGhpcy5wcm9wcy5hZGRyZXNzfS9yZXF1ZXN0c2ApO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHsgZXJyb3JNZXNzYWdlOiBlcnIubWVzc2FnZSB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyBsb2FkaW5nQTogZmFsc2UgfSk7XHJcblxyXG4gICAgfTtcclxuXHJcbiAgICBvbkZpbmFsaXplID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyBsb2FkaW5nRjogdHJ1ZSwgZXJyb3JNZXNzYWdlOiAnJ30pO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGNhbXBhaWduID0gQ2FtcGFpZ24odGhpcy5wcm9wcy5hZGRyZXNzKTtcclxuICAgICAgICAgICAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCB3ZWIzLmV0aC5nZXRBY2NvdW50cygpO1xyXG4gICAgICAgICAgICBhd2FpdCBjYW1wYWlnbi5tZXRob2RzLmZpbmFsaXplUmVxdWVzdCh0aGlzLnByb3BzLmlkKVxyXG4gICAgICAgICAgICAgICAgLnNlbmQoeyBmcm9tOiBhY2NvdW50c1swXSB9KTtcclxuICAgICAgICAgICAgUm91dGVyLnJlcGxhY2VSb3V0ZShgL2NhbXBhaWducy8ke3RoaXMucHJvcHMuYWRkcmVzc30vcmVxdWVzdHNgKTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IGVycm9yTWVzc2FnZTogZXJyLm1lc3NhZ2UgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLnNldFN0YXRlKHsgbG9hZGluZ0Y6IGZhbHNlIH0pO1xyXG5cclxuICAgIH07XHJcblxyXG4gICAgcmVuZGVyKCkge1xyXG4gICAgICAgIGNvbnN0IHsgUm93LCBDZWxsIH0gPSBUYWJsZTtcclxuICAgICAgICBjb25zdCB7IGlkLCByZXF1ZXN0LCBhcHByb3ZlcnNDb3VudCB9ID0gdGhpcy5wcm9wcztcclxuICAgICAgICBjb25zdCByZWFkeVRvRmluYWxpemUgPSByZXF1ZXN0LmFwcHJvdmFsQ291bnQgPj0gYXBwcm92ZXJzQ291bnQgLyAyO1xyXG5cclxuICAgICAgICByZXR1cm4gKCBcclxuICAgICAgICAgICAgPFJvdyBkaXNhYmxlZCA9IHtyZXF1ZXN0LmNvbXBsZXRlfSBwb3NpdGl2ZSA9IHtyZWFkeVRvRmluYWxpemUgJiYgIXJlcXVlc3QuY29tcGxldGV9PlxyXG4gICAgICAgICAgICAgICAgPENlbGw+e2lkfTwvQ2VsbD5cclxuICAgICAgICAgICAgICAgIDxDZWxsPntyZXF1ZXN0LmRlc2NyaXB0aW9ufTwvQ2VsbD5cclxuICAgICAgICAgICAgICAgIDxDZWxsPnt3ZWIzLnV0aWxzLmZyb21XZWkoIHJlcXVlc3QudmFsdWUsICdldGhlcicpfTwvQ2VsbD5cclxuICAgICAgICAgICAgICAgIDxDZWxsPntyZXF1ZXN0LnJlY2lwaWVudH08L0NlbGw+XHJcbiAgICAgICAgICAgICAgICA8Q2VsbD57cmVxdWVzdC5hcHByb3ZhbENvdW50fS97YXBwcm92ZXJzQ291bnR9PC9DZWxsPlxyXG4gICAgICAgICAgICAgICAgPENlbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgeyByZXF1ZXN0LmNvbXBsZXRlID8gbnVsbCA6IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAoPEJ1dHRvbiBiYXNpYyBjb2xvcj1cImdyZWVuXCIgb25DbGljaz17dGhpcy5vbkFwcHJvdmV9IGxvYWRpbmcgPSB7dGhpcy5zdGF0ZS5sb2FkaW5nQX0gZGlzYWJsZWQgPSB7dGhpcy5zdGF0ZS5sb2FkaW5nQX0+QXBwcm92ZTwvQnV0dG9uPil9XHJcbiAgICAgICAgICAgICAgICA8L0NlbGw+XHJcbiAgICAgICAgICAgICAgICA8Q2VsbD5cclxuICAgICAgICAgICAgICAgICAgICB7IHJlcXVlc3QuY29tcGxldGUgPyBudWxsIDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgKDxCdXR0b24gYmFzaWMgY29sb3I9XCJ0ZWFsXCIgb25DbGljaz17dGhpcy5vbkZpbmFsaXplfSBsb2FkaW5nID0ge3RoaXMuc3RhdGUubG9hZGluZ0Z9IGRpc2FibGVkID0ge3RoaXMuc3RhdGUubG9hZGluZ0Z9PkZpbmFsaXplPC9CdXR0b24+KX1cclxuICAgICAgICAgICAgICAgIDwvQ2VsbD5cclxuICAgICAgICAgICAgICAgIDxDZWxsIGVycm9yID0geyEhdGhpcy5zdGF0ZS5lcnJvck1lc3NhZ2V9PlxyXG4gICAgICAgICAgICAgICAgeyEhdGhpcy5zdGF0ZS5lcnJvck1lc3NhZ2U/PE1lc3NhZ2UgZXJyb3IgaGVhZGVyID0gXCJPb3BzIVwiIGNvbnRlbnQgPSB7dGhpcy5zdGF0ZS5lcnJvck1lc3NhZ2V9Lz46bnVsbH1cclxuICAgICAgICAgICAgICAgIDwvQ2VsbD5cclxuICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVxdWVzdFJvdzsiLCJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBCdXR0b24sIFRhYmxlIH0gZnJvbSAnc2VtYW50aWMtdWktcmVhY3QnO1xyXG5cclxuaW1wb3J0IExheW91dCBmcm9tICcuLi8uLi8uLi9jb21wb25lbnRzL0xheW91dCc7XHJcbmltcG9ydCBSZXF1ZXN0Um93IGZyb20gJy4uLy4uLy4uL2NvbXBvbmVudHMvUmVxdWVzdFJvdyc7XHJcblxyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAnLi4vLi4vLi4vcm91dGVzJztcclxuXHJcbmltcG9ydCBDYW1wYWlnbiBmcm9tICcuLi8uLi8uLi9ldGhlcmV1bS9jYW1wYWlnbic7XHJcblxyXG5jbGFzcyBSZXF1ZXN0SW5kZXggZXh0ZW5kcyBDb21wb25lbnQge1xyXG4gICAgc3RhdGljIGFzeW5jIGdldEluaXRpYWxQcm9wcyhwcm9wcykge1xyXG4gICAgICAgIGNvbnN0IHsgYWRkcmVzcyB9ID0gcHJvcHMucXVlcnk7XHJcbiAgICAgICAgLy9Tb2xpZGl0eSBkb2VzIG5vdCBzdXBwb3J0IHJldHVybmluZyBhbiBhcnJheSBvZiB1c2VyIGRlZmluZWQgdHlwZXMgbGlrZSBzdHJ1Y3RzIC1cclxuICAgICAgICAvL1RvIGdldCBhIGxpc3Qgb2YgYWxsIHJlcXVlc3RzLCB3ZSBuZWVkIHRvIGNhbGwgc2VwYXJhdGVseSBmb3IgZWFjaCByZXF1ZXN0XHJcbiAgICAgICAgLy9Vc2UgdGhlIHJlcXVlc3RzIGNvdW50IGFuZCBjYWxsIGVhY2ggb25lXHJcbiAgICAgICAgY29uc3QgY2FtcGFpZ24gPSBDYW1wYWlnbihhZGRyZXNzKTtcclxuICAgICAgICBjb25zdCByZXF1ZXN0Q291bnQgPSBhd2FpdCBjYW1wYWlnbi5tZXRob2RzLmdldFJlcXVlc3RzQ291bnQoKS5jYWxsKCk7XHJcbiAgICAgICAgY29uc3QgYXBwcm92ZXJzQ291bnQgPSBhd2FpdCBjYW1wYWlnbi5tZXRob2RzLmFwcHJvdmVyc0NvdW50KCkuY2FsbCgpO1xyXG5cclxuICAgICAgICAvL0luc3RlYWQgb2YgY3JlYXRpbmcgYSBsb29wIGFuZCBmZXRjaGluZyByZXF1ZXN0cyBvbmUgYnkgb25lLCBzZW5kIHRoZW0gYWxsIHRvZ2V0aGVyIFxyXG4gICAgICAgIC8vQXJyYXkuZmlsbChudW0pLm1hcCguLi4pIC0gZ2l2ZXMgYWxsIHRoZSBpbmRpY2VzIGZyb20gMCB0byBudW1cclxuICAgICAgICBjb25zdCByZXF1ZXN0cyA9IGF3YWl0IFByb21pc2UuYWxsKFxyXG4gICAgICAgICAgICBBcnJheShwYXJzZUludChyZXF1ZXN0Q291bnQpKS5maWxsKCkubWFwKCggZWxlbWVudCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBjYW1wYWlnbi5tZXRob2RzLnJlcXVlc3RzKGluZGV4KS5jYWxsKClcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBjb25zb2xlLmxvZyhyZXF1ZXN0cyk7XHJcblxyXG4gICAgICAgIHJldHVybiB7IGFkZHJlc3MsIHJlcXVlc3RzLCByZXF1ZXN0Q291bnQsIGFwcHJvdmVyc0NvdW50IH07XHJcbiAgICB9XHJcblxyXG4gICAgcmVuZGVyUm93cygpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5wcm9wcy5yZXF1ZXN0cy5tYXAoKHJlcXVlc3QsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiA8UmVxdWVzdFJvd1xyXG4gICAgICAgICAgICAgICAga2V5ID0ge2luZGV4fVxyXG4gICAgICAgICAgICAgICAgaWQgPSB7aW5kZXh9XHJcbiAgICAgICAgICAgICAgICByZXF1ZXN0ID0ge3JlcXVlc3R9XHJcbiAgICAgICAgICAgICAgICBhZGRyZXNzID0ge3RoaXMucHJvcHMuYWRkcmVzc31cclxuICAgICAgICAgICAgICAgIGFwcHJvdmVyc0NvdW50ID0ge3RoaXMucHJvcHMuYXBwcm92ZXJzQ291bnR9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcblxyXG4gICAgcmVuZGVyKCl7XHJcbiAgICAgICAgY29uc3QgeyBIZWFkZXIsIFJvdywgSGVhZGVyQ2VsbCwgQm9keSB9ID0gVGFibGU7XHJcblxyXG4gICAgICAgIHJldHVybihcclxuICAgICAgICAgICAgPExheW91dD5cclxuICAgICAgICAgICAgICAgIDxMaW5rIHJvdXRlID0ge2AvY2FtcGFpZ25zLyR7dGhpcy5wcm9wcy5hZGRyZXNzfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxhPkJhY2s8L2E+XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8aDM+UmVxdWVzdHM8L2gzPlxyXG4gICAgICAgICAgICAgICAgPExpbmsgcm91dGU9e2AvY2FtcGFpZ25zLyR7dGhpcy5wcm9wcy5hZGRyZXNzfS9yZXF1ZXN0cy9uZXdgfT5cclxuICAgICAgICAgICAgICAgICAgICA8YT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBwcmltYXJ5IGZsb2F0ZWQgPSBcInJpZ2h0XCIgc3R5bGUgPSB7eyBtYXJnaW5Cb3R0b206IDEwIH19PkFkZCBSZXF1ZXN0PC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPFRhYmxlPlxyXG4gICAgICAgICAgICAgICAgICAgIDxIZWFkZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SGVhZGVyQ2VsbD5JRDwvSGVhZGVyQ2VsbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxIZWFkZXJDZWxsPkRlc2NyaXB0aW9uPC9IZWFkZXJDZWxsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEhlYWRlckNlbGw+QW1vdW50PC9IZWFkZXJDZWxsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEhlYWRlckNlbGw+UmVjaXBpZW50PC9IZWFkZXJDZWxsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEhlYWRlckNlbGw+QXBwcm92YWwgQ291bnQ8L0hlYWRlckNlbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SGVhZGVyQ2VsbD5BcHByb3ZlPC9IZWFkZXJDZWxsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEhlYWRlckNlbGw+RmluYWxpemU8L0hlYWRlckNlbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SGVhZGVyQ2VsbD5Ob3RlczwvSGVhZGVyQ2VsbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9IZWFkZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0aGlzLnJlbmRlclJvd3MoKX1cclxuICAgICAgICAgICAgICAgICAgICA8L0JvZHk+XHJcbiAgICAgICAgICAgICAgICA8L1RhYmxlPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5Gb3VuZCB7dGhpcy5wcm9wcy5yZXF1ZXN0Q291bnR9IHJlcXVlc3RzLjwvZGl2PlxyXG4gICAgICAgICAgICA8L0xheW91dD5cclxuICAgICAgICApO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSZXF1ZXN0SW5kZXg7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC1yb3V0ZXNcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvaGVhZFwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic2VtYW50aWMtdWktcmVhY3RcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIndlYjNcIik7OyJdLCJzb3VyY2VSb290IjoiIn0=